import feedparser
from core.models import Signal,SignalKind,Evidence
def fetch_regulations(region,days):
    if region!="DE": return []
    f=feedparser.parse("https://www.bundesanzeiger.de/pub/atom/news"); out=[]
    for e in f.entries[:20]:
        t=getattr(e,"title","").strip()
        if t and any(w in t.lower() for w in ("gesetz","verordnung","änderung")):
            out.append(Signal(source="bundesanzeiger",kind=SignalKind.regulation,topic=t,region=region,demand=.55,growth=.55,regulatory_pressure=.9,evidence=[Evidence(source="Bundesanzeiger",title=t,url=getattr(e,"link",None))]))
    return out
