from core.models import Signal,SignalKind,Evidence
def fetch_trends(keyword,region,days):
    from pytrends.request import TrendReq
    c=TrendReq(hl="de",tz=60); c.build_payload([keyword],timeframe=f"today {days}-d",geo=region)
    d=c.interest_over_time()
    if d.empty or keyword not in d: return []
    v=[float(x) for x in d[keyword].tolist()]; recent=sum(v[-3:])/len(v[-3:]); old=sum(v[:-3])/len(v[:-3]) if len(v)>3 else recent
    return [Signal(source="google_trends",kind=SignalKind.trend,topic=keyword,region=region,demand=min(recent/100,1),growth=max(0,min((recent-old+100)/200,1)),evidence=[Evidence(source="Google Trends",title=keyword)])]
