import requests
from bs4 import BeautifulSoup
from core.models import Signal,SignalKind,Evidence
def fetch_jobs(keyword,region,days):
    if region!="DE": return []
    r=requests.get("https://de.indeed.com/jobs",params={"q":keyword,"sort":"date"},headers={"User-Agent":"Mozilla/5.0 NischeExplorer/1.0"},timeout=10); r.raise_for_status()
    out=[]
    for x in BeautifulSoup(r.text,"html.parser").select(".job_seen_beacon")[:20]:
        t=x.select_one(".jobTitle")
        if t: out.append(Signal(source="indeed",kind=SignalKind.job,topic=keyword,region=region,demand=.65,growth=.5,evidence=[Evidence(source="Indeed",title=t.get_text(" ",strip=True))]))
    return out
