# Nische – Opportunity Explorer Pro

Modularer Nischen- und Marktlücken-Explorer:
Datenquellen → normalisierte Signale → Scoring → Opportunities → Aktionen.

## Start
pip install -r requirements.txt
streamlit run app.py

Optional: `.env` nach `.env.example` konfigurieren.
