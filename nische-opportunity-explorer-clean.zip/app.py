import pandas as pd
import streamlit as st
from core.pipeline import run_pipeline
from actions.book import generate_book_idea
from actions.service import suggest_service, generate_business_plan
from actions.product import suggest_product
from actions.print_on_demand import generate_design, export_etsy_csv, export_merch_csv

st.set_page_config(page_title="Nischen- & Marktlücken-Explorer Pro", layout="wide")
st.title("🚀 Nischen- & Marktlücken-Explorer Pro")
st.caption("Signale erkennen → Chancen bewerten → konkrete Maßnahmen ableiten")

with st.sidebar:
    keyword = st.text_input("Suchbegriff", "Künstliche Intelligenz im Handwerk")
    region = st.selectbox("Region", ["DE", "US", "GB", "FR", "IT"])
    days = st.slider("Zeitraum (Tage)", 1, 30, 7)

if not keyword.strip():
    st.stop()

with st.spinner("Analysiere verfügbare Signale …"):
    result = run_pipeline(keyword.strip(), region, days)

score = result.opportunity
signals = result.signals

t1,t2,t3,t4,t5,t6 = st.tabs(["📊 Dashboard","📚 Bücher","💼 Dienstleistungen","📦 Waren","👕 Print-on-Demand","📜 Jobs & Regulierung"])

with t1:
    a,b,c,d = st.columns(4)
    a.metric("Opportunity Score", f"{score.score:.0f}/100")
    b.metric("Signale", len(signals))
    c.metric("Evidenzen", sum(len(s.evidence) for s in signals))
    d.metric("Quellenfehler", len(result.errors))
    st.dataframe(pd.DataFrame([score.model_dump(exclude={"evidence"})]), use_container_width=True)
    for e in score.evidence: st.write("•", e)
    for e in result.errors: st.warning(f"{e.source}: {e.message}")

with t2:
    if st.button("Buchkonzept generieren"):
        st.json(generate_book_idea(keyword))

with t3:
    service = suggest_service(keyword, signals)
    st.json(service)
    if st.button("Businessplan generieren"):
        st.json(generate_business_plan(service))

with t4:
    st.json(suggest_product(keyword, signals))

with t5:
    design = generate_design(keyword, signals)
    st.json(design)
    st.download_button("Etsy CSV", export_etsy_csv(design), f"etsy_{keyword}.csv")
    st.download_button("Amazon Merch CSV", export_merch_csv(design), f"merch_{keyword}.csv")

with t6:
    jobs = [s.model_dump() for s in signals if s.kind.value == "job"]
    laws = [s.model_dump() for s in signals if s.kind.value == "regulation"]
    st.subheader("Jobs")
    st.dataframe(pd.DataFrame(jobs), use_container_width=True)
    st.subheader("Regulierung")
    st.dataframe(pd.DataFrame(laws), use_container_width=True)
