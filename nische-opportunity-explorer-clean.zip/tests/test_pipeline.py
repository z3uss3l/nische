from core.pipeline import run_pipeline
def test_pipeline(monkeypatch):
    monkeypatch.setattr("core.pipeline.fetch_trends",lambda *a:[])
    monkeypatch.setattr("core.pipeline.fetch_jobs",lambda *a:[])
    monkeypatch.setattr("core.pipeline.fetch_regulations",lambda *a:[])
    r=run_pipeline("test","DE",7)
    assert r.signals and r.opportunity.score >= 0
