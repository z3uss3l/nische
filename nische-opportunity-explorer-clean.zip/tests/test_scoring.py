from core.models import Signal,SignalKind
from core.scoring import calculate_opportunity
def test_score_bounded():
    r=calculate_opportunity([Signal(source="t",kind=SignalKind.trend,topic="t",demand=1,growth=1,pain=1,supply=0,regulatory_pressure=1)])
    assert 0 <= r.score <= 100
