from datetime import datetime, timezone
from enum import Enum
from pydantic import BaseModel, Field

class SignalKind(str, Enum):
    trend="trend"; news="news"; social="social"; book="book"; job="job"; regulation="regulation"

class Evidence(BaseModel):
    source: str
    title: str
    url: str|None = None
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict = Field(default_factory=dict)

class Signal(BaseModel):
    source: str
    kind: SignalKind
    topic: str
    region: str|None = None
    demand: float = Field(0, ge=0, le=1)
    pain: float = Field(0, ge=0, le=1)
    supply: float = Field(0, ge=0, le=1)
    growth: float = Field(0, ge=0, le=1)
    regulatory_pressure: float = Field(0, ge=0, le=1)
    evidence: list[Evidence] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)

class Opportunity(BaseModel):
    score: float
    demand: float
    growth: float
    pain: float
    supply: float
    regulatory_pressure: float
    job_signal: float
    confidence: float
    evidence: list[str] = []

class SourceError(BaseModel):
    source: str
    message: str
    cached: bool = False

class PipelineResult(BaseModel):
    signals: list[Signal]
    opportunity: Opportunity
    errors: list[SourceError] = []
