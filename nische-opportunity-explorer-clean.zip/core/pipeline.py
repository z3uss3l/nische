from .models import PipelineResult, Signal, SourceError, SignalKind, Evidence
from .scoring import calculate_opportunity
from sources.trends import fetch_trends
from sources.jobs import fetch_jobs
from sources.laws import fetch_regulations

def run_pipeline(keyword, region, days):
    signals=[]; errors=[]
    for name,fn in [("trends",lambda:fetch_trends(keyword,region,days)),("jobs",lambda:fetch_jobs(keyword,region,days)),("regulations",lambda:fetch_regulations(region,days))]:
        try: signals.extend(fn())
        except Exception as exc: errors.append(SourceError(source=name,message=str(exc)))
    if not signals:
        signals=[Signal(source="pipeline",kind=SignalKind.news,topic=keyword,evidence=[Evidence(source="pipeline",title="Keine externen Signale")])]
    return PipelineResult(signals=signals,opportunity=calculate_opportunity(signals),errors=errors)
