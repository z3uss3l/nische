from .models import Opportunity, Signal

def calculate_opportunity(signals: list[Signal]) -> Opportunity:
    if not signals:
        return Opportunity(score=0,demand=0,growth=0,pain=0,supply=0,regulatory_pressure=0,job_signal=0,confidence=0,evidence=["Keine verwertbaren Signale."])
    avg=lambda k: sum(getattr(s,k) for s in signals)/len(signals)
    demand,growth,pain,supply,reg=map(avg,["demand","growth","pain","supply","regulatory_pressure"])
    jobs=min(sum(s.kind.value=="job" for s in signals)/10,1)
    confidence=min(sum(len(s.evidence) for s in signals)/20,1)
    score=max(0,min(100,demand*24+growth*20+pain*20+reg*14+jobs*12+confidence*10-supply*20))
    return Opportunity(score=round(score,2),demand=round(demand,3),growth=round(growth,3),pain=round(pain,3),supply=round(supply,3),regulatory_pressure=round(reg,3),job_signal=round(jobs,3),confidence=round(confidence,3),evidence=[f"Demand {demand:.2f}",f"Wachstum {growth:.2f}",f"Pain {pain:.2f}",f"Supply {supply:.2f}",f"Regulierung {reg:.2f}",f"Jobs {jobs:.2f}",f"Confidence {confidence:.2f}"])
