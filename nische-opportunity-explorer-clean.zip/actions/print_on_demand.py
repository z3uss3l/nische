from io import StringIO
import pandas as pd
import os
def generate_design(topic,signals):
    if not os.getenv("OPENAI_API_KEY"): return {"status":"draft","topic":topic,"slogan":f"{topic} – heute schon verstanden","description":f"Print-on-demand Konzept zum Thema {topic}","target_group":"Interessierte am Thema","colors":["Schwarz","Weiß","Grau"]}
    from openai import OpenAI
    r=OpenAI().responses.create(model=os.getenv("OPENAI_MODEL","gpt-5"),input=f"Erstelle ein rechtlich unbedenkliches Print-on-demand Designkonzept für {topic}. Keine fremden Marken, Logos oder Personen.")
    return {"topic":topic,"raw":r.output_text}
def export_etsy_csv(d):
    o=StringIO(); pd.DataFrame([{"title":d.get("slogan",d.get("topic","")),"description":d.get("description",""),"tags":d.get("target_group","")}]).to_csv(o,index=False); return o.getvalue()
def export_merch_csv(d):
    o=StringIO(); pd.DataFrame([{"title":d.get("slogan",d.get("topic","")),"description":d.get("description",""),"brand":"Nische Explorer"}]).to_csv(o,index=False); return o.getvalue()
