import os
def generate_book_idea(topic):
    if not os.getenv("OPENAI_API_KEY"): return {"status":"not_generated","topic":topic,"reason":"OPENAI_API_KEY nicht konfiguriert"}
    from openai import OpenAI
    r=OpenAI().responses.create(model=os.getenv("OPENAI_MODEL","gpt-5"),input=f"Erstelle ein Sachbuchkonzept zum Thema {topic}. Titel, Zielgruppe, Nutzenversprechen und Kapitelstruktur.")
    return {"topic":topic,"raw":r.output_text}
