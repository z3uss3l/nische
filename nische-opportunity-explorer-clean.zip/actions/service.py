def suggest_service(topic,signals):
    return {"name":f"Beratung für {topic}","problem_evidence":[s.evidence[0].title for s in signals if s.pain>.4 and s.evidence][:5],"validation":"Kundeninterviews + Landingpage + Vorverkauf","pricing":"Projekt- oder Paketpreis"}
def generate_business_plan(service):
    return {"business":service["name"],"problem":service["problem_evidence"],"validation":service["validation"],"next_steps":["Kunden validieren","Preis testen","Landingpage erstellen","Pilotkunden gewinnen"]}
