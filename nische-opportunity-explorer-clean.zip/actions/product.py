def suggest_product(topic,signals):
    return {"topic":topic,"product":f"Problemorientiertes Produkt für {topic}","evidence_count":sum(len(s.evidence) for s in signals),"validation":"Demand per Landingpage oder Vorbestellung prüfen"}
